import { HttpError } from './httpErrors';
import { InertiaProtocolError } from './protocol';
/** Callback, renderer, or browser operation failure during a navigation. */
export declare class NavigationError extends Error {
    readonly cause: unknown;
    readonly _tag = "NavigationError";
    constructor(cause: unknown);
}
export type NavigationFailure = HttpError | InertiaProtocolError | NavigationError;
export declare function navigationFailure(cause: unknown): NavigationFailure;
