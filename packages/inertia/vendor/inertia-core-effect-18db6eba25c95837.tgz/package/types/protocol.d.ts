import { Effect, Schema } from 'effect';
import { Page } from './types';
/** The server owns arbitrary prop values; Inertia validates only its protocol envelope. */
export declare const PageSchema: Schema.Struct<{
    readonly component: Schema.String;
    readonly url: Schema.String;
    readonly version: Schema.Union<readonly [Schema.String, Schema.Null]>;
    readonly props: Schema.$Record<Schema.String, Schema.Unknown>;
    readonly clearHistory: Schema.optional<Schema.Boolean>;
    readonly encryptHistory: Schema.optional<Schema.Boolean>;
    readonly preserveFragment: Schema.optional<Schema.Boolean>;
    readonly preserveBigIntegers: Schema.optional<Schema.Boolean>;
    readonly deferredProps: Schema.optional<Schema.$Record<Schema.String, Schema.$Array<Schema.String>>>;
    readonly initialDeferredProps: Schema.optional<Schema.$Record<Schema.String, Schema.$Array<Schema.String>>>;
    readonly rescuedProps: Schema.optional<Schema.$Array<Schema.String>>;
    readonly mergeProps: Schema.optional<Schema.$Array<Schema.String>>;
    readonly prependProps: Schema.optional<Schema.$Array<Schema.String>>;
    readonly deepMergeProps: Schema.optional<Schema.$Array<Schema.String>>;
    readonly matchPropsOn: Schema.optional<Schema.$Array<Schema.String>>;
    readonly sharedProps: Schema.optional<Schema.$Array<Schema.String>>;
    readonly flash: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
    readonly rememberedState: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
    readonly optimisticUpdatedAt: Schema.optional<Schema.$Record<Schema.String, Schema.Number>>;
    readonly scrollProps: Schema.optional<Schema.$Record<Schema.String, Schema.Struct<{
        readonly pageName: Schema.String;
        readonly previousPage: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Null]>;
        readonly nextPage: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Null]>;
        readonly currentPage: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Null]>;
        readonly reset: Schema.Boolean;
    }>>>;
    readonly onceProps: Schema.optional<Schema.$Record<Schema.String, Schema.Struct<{
        readonly prop: Schema.String;
        readonly expiresAt: Schema.optional<Schema.Union<readonly [Schema.Number, Schema.Null]>>;
    }>>>;
}>;
export declare class InertiaProtocolError extends Error {
    readonly cause: unknown;
    readonly _tag = "InertiaProtocolError";
    constructor(cause: unknown);
}
export declare function validatePageEffect(value: unknown): Effect.Effect<Page, InertiaProtocolError>;
export declare function decodePageEffect(text: string): Effect.Effect<Page, InertiaProtocolError>;
export declare function decodePage(text: string): Page;
