import { Effect, Fiber } from 'effect';
import { ActiveVisit, CacheForOption, InFlightPrefetch, InternalActiveVisit, Page, PrefetchedResponse, PrefetchOptions } from './types';
declare class PrefetchedRequests {
    protected cached: PrefetchedResponse[];
    protected inFlightRequests: InFlightPrefetch[];
    protected removalTimers: {
        params: ActiveVisit;
        timer: Fiber.Fiber<void>;
    }[];
    private readonly lifetime;
    private responseEffects;
    private cancelConsumption?;
    protected currentUseId: string | null;
    add(params: ActiveVisit, sendFunc: (params: InternalActiveVisit) => void, options: PrefetchOptions): Promise<unknown>;
    addEffect(params: ActiveVisit, sendFunc: (params: InternalActiveVisit) => Effect.Effect<unknown, unknown>, { cacheFor, cacheTags }: PrefetchOptions): Effect.Effect<void, unknown>;
    removeAll(): void;
    removeByTags(tags: string[]): void;
    remove(params: ActiveVisit): void;
    protected removeFromInFlight(visitId: string): void;
    protected extractStaleValues(cacheFor: PrefetchOptions['cacheFor']): [number, number];
    protected cacheForToStaleAndExpires(cacheFor: PrefetchOptions['cacheFor']): [CacheForOption, CacheForOption];
    protected clearTimer(params: ActiveVisit): void;
    protected scheduleForRemoval(params: ActiveVisit, expiresIn: number): void;
    get(params: ActiveVisit): InFlightPrefetch | PrefetchedResponse | null;
    use(prefetched: PrefetchedResponse | InFlightPrefetch, params: ActiveVisit): Promise<unknown>;
    cancelUse(): void;
    useEffect(prefetched: PrefetchedResponse | InFlightPrefetch, params: ActiveVisit): Effect.Effect<import('./types').VisitOutcome, unknown>;
    protected removeSingleUseItems(params: ActiveVisit): void;
    findCached(params: ActiveVisit): PrefetchedResponse | null;
    findInFlight(params: ActiveVisit): InFlightPrefetch | null;
    protected withoutPurposePrefetchHeader(params: ActiveVisit): ActiveVisit;
    protected paramsAreEqual(params1: ActiveVisit, params2: ActiveVisit): boolean;
    updateCachedOncePropsFromCurrentPage(): void;
    protected getShortestOncePropTtl(page: Page): number | null;
}
export declare const prefetchedRequests: PrefetchedRequests;
export {};
