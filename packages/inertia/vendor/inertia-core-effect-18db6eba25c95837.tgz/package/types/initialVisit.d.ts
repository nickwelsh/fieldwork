import { Effect, Fiber } from 'effect';
export declare class InitialVisit {
    private static lifetime;
    static dispose(): void;
    static handle(): Fiber.Fiber<void, unknown>;
    static handleEffect(): Effect.Effect<void, unknown>;
    protected static clearRememberedStateOnReload(): void;
    protected static handleBackForward(): Effect.Effect<void, unknown>;
    /**
     * @link https://inertiajs.com/redirects#external-redirects
     */
    protected static handleLocation(): Effect.Effect<void, unknown>;
    protected static handleDefault(): Effect.Effect<void, unknown>;
    protected static fireInitialEvents(visitId: string): void;
}
