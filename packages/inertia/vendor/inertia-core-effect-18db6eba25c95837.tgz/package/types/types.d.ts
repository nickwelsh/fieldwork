import type { Effect } from 'effect';
import type { Effectful } from './effectInterop';
import type { HttpCancelledError, HttpNetworkError, HttpResponseError } from './httpErrors';
import { InfiniteScrollOnCompleteDetails, InfiniteScrollPageIdentifier } from './infiniteScroll/data';
import { NamedInputEvent, ValidationConfig, Validator } from './precognition';
import { Response } from './response';
export type HttpRequestHeaders = Record<string, unknown>;
export type HttpResponseHeaders = Record<string, string>;
export interface HttpProgressEvent {
    progress: number | undefined;
    loaded: number;
    total: number | undefined;
    percentage?: number;
}
export interface HttpRequestConfig {
    method: Method;
    url: string;
    data?: unknown;
    params?: Record<string, unknown>;
    headers?: HttpRequestHeaders;
    signal?: AbortSignal;
    onUploadProgress?: (event: HttpProgressEvent) => void;
}
export interface HttpResponse {
    status: number;
    data: string;
    headers: HttpResponseHeaders;
}
export interface HttpExceptionResponse extends Omit<HttpResponse, 'data'> {
    data: string | Record<string, unknown>;
}
export interface HttpClient {
    request(config: HttpRequestConfig): Promise<HttpResponse>;
    requestEffect?(config: HttpRequestConfig): Effect.Effect<HttpResponse, unknown>;
}
export interface HttpClientOptions {
    xsrfCookieName?: string;
    xsrfHeaderName?: string;
}
export type HttpRequestHandler = (config: HttpRequestConfig) => HttpRequestConfig | Promise<HttpRequestConfig> | Effect.Effect<HttpRequestConfig, unknown>;
export type HttpResponseHandler = (response: HttpResponse) => HttpResponse | Promise<HttpResponse> | Effect.Effect<HttpResponse, unknown>;
export type HttpErrorHandler = (error: HttpResponseError | HttpNetworkError | HttpCancelledError) => void | Promise<void> | Effect.Effect<void, unknown>;
export interface PageFlashData {
    [key: string]: unknown;
}
export type DefaultInertiaConfig = {
    errorValueType: string;
    flashDataType: PageFlashData;
    sharedPageProps: PageProps;
    layoutProps: Record<string, unknown>;
    namedLayoutProps: Record<string, Record<string, unknown>>;
};
/**
 * Designed to allow overriding of some core types using TypeScript
 * interface declaration merging.
 *
 * @see {@link DefaultInertiaConfig} for keys to override
 * @example
 * ```ts
 * // global.d.ts
 * import '@inertiajs/core'
 *
 * declare module '@inertiajs/core' {
 *   export interface InertiaConfig {
 *     errorValueType: string[]
 *     flashDataType: {
 *       toast?: { type: 'success' | 'error', message: string }
 *     }
 *     sharedPageProps: {
 *       auth: { user: User | null }
 *     }
 *     layoutProps: {
 *       title: string
 *       showSidebar: boolean
 *     }
 *     namedLayoutProps: {
 *       app: { title: string; theme: string }
 *       content: { padding: string; maxWidth: string }
 *     }
 *   }
 * }
 * ```
 */
export interface InertiaConfig {
}
export type InertiaConfigFor<Key extends keyof DefaultInertiaConfig> = Key extends keyof InertiaConfig ? InertiaConfig[Key] : DefaultInertiaConfig[Key];
export type ErrorValue = InertiaConfigFor<'errorValueType'>;
export type FlashData = InertiaConfigFor<'flashDataType'>;
export type SharedPageProps = InertiaConfigFor<'sharedPageProps'>;
export type LayoutProps = InertiaConfigFor<'layoutProps'>;
export type NamedLayoutProps = InertiaConfigFor<'namedLayoutProps'>;
export type Errors = Record<string, ErrorValue>;
export type ErrorBag = Record<string, Errors>;
export type FormDataConvertibleValue = Blob | FormDataEntryValue | Date | boolean | number | bigint | null | undefined;
export type FormDataConvertible = Array<FormDataConvertible> | {
    [key: string]: FormDataConvertible;
} | FormDataConvertibleValue;
export type FormDataType<T extends object> = {
    [K in keyof T]: T[K] extends infer U ? U extends FormDataConvertibleValue ? U : U extends (...args: unknown[]) => unknown ? never : U extends object | Array<unknown> ? FormDataType<U> : never : never;
};
/**
 * Uses `0 extends 1 & T` to detect `any` type and prevent infinite recursion.
 */
export type FormDataKeys<T> = T extends Function | FormDataConvertibleValue ? never : T extends unknown[] ? ArrayFormDataKeys<T> : T extends object ? ObjectFormDataKeys<T> : never;
/**
 * Helper type for array form data keys
 */
type ArrayFormDataKeys<T extends unknown[]> = number extends T['length'] ? `${number}` | (0 extends 1 & T[number] ? never : T[number] extends FormDataConvertibleValue ? never : `${number}.${FormDataKeys<T[number]>}`) : Extract<keyof T, `${number}`> | {
    [Key in Extract<keyof T, `${number}`>]: 0 extends 1 & T[Key] ? never : T[Key] extends FormDataConvertibleValue ? never : `${Key & string}.${FormDataKeys<T[Key & string] & string>}`;
}[Extract<keyof T, `${number}`>];
/**
 * Helper type for object form data keys
 */
type ObjectFormDataKeys<T extends object> = string extends keyof T ? string : Extract<keyof T, string> | {
    [Key in Extract<keyof T, string>]: 0 extends 1 & T[Key] ? never : T[Key] extends FormDataConvertibleValue ? never : T[Key] extends any[] ? `${Key}.${FormDataKeys<T[Key]> & string}` : T[Key] extends Record<string, any> ? `${Key}.${FormDataKeys<T[Key]> & string}` : Exclude<T[Key], null | undefined> extends any[] ? never : Exclude<T[Key], null | undefined> extends Record<string, any> ? `${Key}.${FormDataKeys<Exclude<T[Key], null | undefined>> & string}` : never;
}[Extract<keyof T, string>];
type PartialFormDataErrors<T> = {
    [K in string extends keyof T ? string : Extract<keyof FormDataError<T>, string>]?: ErrorValue;
};
export type FormDataErrors<T> = PartialFormDataErrors<T> & {
    [K in keyof PartialFormDataErrors<T>]: NonNullable<PartialFormDataErrors<T>[K]>;
};
export type FormDataValues<T, K extends FormDataKeys<T>> = K extends `${infer P}.${infer Rest}` ? T extends unknown[] ? P extends `${infer I extends number}` ? Rest extends FormDataKeys<T[I]> ? FormDataValues<T[I], Rest> : never : never : P extends keyof T ? Rest extends FormDataKeys<T[P]> ? FormDataValues<T[P], Rest> : never : never : K extends keyof T ? T[K] : T extends unknown[] ? T[K & number] : never;
export type FormDataError<T> = Partial<Record<FormDataKeys<T>, ErrorValue>>;
export type Method = 'get' | 'post' | 'put' | 'patch' | 'delete';
export type RequestPayload = Record<string, FormDataConvertible> | FormData;
export interface PageProps {
    [key: string]: unknown;
}
export type ScrollProp = {
    pageName: string;
    previousPage: InfiniteScrollPageIdentifier;
    nextPage: InfiniteScrollPageIdentifier;
    currentPage: InfiniteScrollPageIdentifier;
    reset: boolean;
};
export interface Page<SharedProps extends PageProps = PageProps> {
    component: string;
    props: PageProps & SharedProps & {
        errors: Errors & ErrorBag;
        deferred?: Record<string, VisitOptions['only']>;
    };
    url: string;
    version: string | null;
    clearHistory?: boolean;
    preserveFragment?: boolean;
    encryptHistory?: boolean;
    preserveBigIntegers?: boolean;
    deferredProps?: Record<string, NonNullable<VisitOptions['only']>>;
    initialDeferredProps?: Record<string, NonNullable<VisitOptions['only']>>;
    rescuedProps: string[];
    mergeProps?: string[];
    prependProps?: string[];
    deepMergeProps?: string[];
    matchPropsOn?: string[];
    sharedProps?: string[];
    scrollProps?: Record<keyof PageProps, ScrollProp>;
    flash: FlashData;
    onceProps?: Record<string, {
        prop: keyof PageProps;
        expiresAt?: number | null;
    }>;
    /** @internal */
    rememberedState: Record<string, unknown>;
    /** @internal */
    optimisticUpdatedAt?: Record<string, number>;
}
export type ScrollRegion = {
    top: number;
    left: number;
};
export interface ClientSideVisitOptions<TProps = Page['props']> {
    component?: Page['component'];
    url?: Page['url'];
    props?: ((props: TProps, onceProps: Partial<TProps>) => PageProps) | PageProps;
    flash?: ((flash: FlashData) => PageFlashData) | PageFlashData;
    clearHistory?: Page['clearHistory'];
    encryptHistory?: Page['encryptHistory'];
    preserveScroll?: VisitOptions['preserveScroll'];
    preserveState?: VisitOptions['preserveState'];
    errorBag?: string | null;
    viewTransition?: VisitOptions['viewTransition'];
    onError?: (errors: Errors) => Effectful<unknown>;
    onFinish?: (visit: ClientSideVisitOptions<TProps>) => Effectful<unknown>;
    onFlash?: (flash: FlashData) => Effectful<unknown>;
    onSuccess?: (page: Page<SharedPageProps>) => Effectful<unknown>;
}
export type PageResolver = (name: string, page?: Page<SharedPageProps>) => Component;
export type PageHandler<ComponentType = Component> = ({ component, page, preserveState, initialRender, }: {
    component: ComponentType;
    page: Page;
    preserveState: boolean;
    initialRender: boolean;
}) => Effectful<unknown>;
export type PreserveStateOption = boolean | 'errors' | ((page: Page) => boolean);
export type QueryStringArrayFormatOption = 'indices' | 'brackets';
export type Progress = HttpProgressEvent;
export type LocationVisit = {
    preserveScroll: boolean;
};
export type CancelToken = {
    cancel: VoidFunction;
};
export type CancelTokenCallback = (cancelToken: CancelToken) => Effectful<unknown>;
export type OptimisticCallback<TProps = Page<SharedPageProps>['props']> = (props: TProps) => Partial<TProps> | void;
export type Visit<T extends RequestPayload = RequestPayload> = {
    method: Method;
    data: T;
    replace: boolean;
    preserveScroll: PreserveStateOption;
    preserveState: PreserveStateOption;
    only: Array<string>;
    except: Array<string>;
    headers: Record<string, string>;
    errorBag: string | null;
    forceFormData: boolean;
    queryStringArrayFormat: QueryStringArrayFormatOption;
    async: boolean;
    showProgress: boolean;
    prefetch: boolean;
    fresh: boolean;
    reset: string[];
    preserveUrl: boolean;
    preserveErrors: boolean;
    invalidateCacheTags: string | string[];
    viewTransition: boolean | ((viewTransition: ViewTransition) => void);
    optimistic?: OptimisticCallback;
    component: string | null;
    pageProps: Record<string, unknown> | ((currentProps: PageProps, sharedProps: Partial<PageProps>) => Record<string, unknown>) | null;
    cached: boolean;
};
export type GlobalEventsMap<T extends RequestPayload = RequestPayload> = {
    before: {
        parameters: [PendingVisit<T>];
        details: {
            visit: PendingVisit<T>;
        };
        result: boolean | void;
    };
    start: {
        parameters: [PendingVisit<T>];
        details: {
            visit: PendingVisit<T>;
        };
        result: void;
    };
    progress: {
        parameters: [Progress | undefined];
        details: {
            progress: Progress | undefined;
        };
        result: void;
    };
    finish: {
        parameters: [ActiveVisit<T>];
        details: {
            visit: ActiveVisit<T>;
        };
        result: void;
    };
    cancel: {
        parameters: [];
        details: {};
        result: void;
    };
    beforeUpdate: {
        parameters: [Page<SharedPageProps>];
        details: {
            page: Page<SharedPageProps>;
        };
        result: void;
    };
    navigate: {
        parameters: [Page<SharedPageProps>, {
            type: 'initial' | 'visit' | 'history';
            cached?: boolean;
            visitId?: string;
        }];
        details: {
            page: Page<SharedPageProps>;
            type: 'initial' | 'visit' | 'history';
            cached?: boolean;
            visitId?: string;
        };
        result: void;
    };
    clientVisit: {
        parameters: [Page<SharedPageProps>, {
            replace: boolean;
            visitId: string;
        }];
        details: {
            page: Page<SharedPageProps>;
            replace: boolean;
            visitId: string;
        };
        result: void;
    };
    success: {
        parameters: [Page<SharedPageProps>, {
            visitId?: string;
        }?];
        details: {
            page: Page<SharedPageProps>;
            visitId?: string;
        };
        result: void;
    };
    error: {
        parameters: [Errors, {
            page?: Page<SharedPageProps>;
            visitId?: string;
        }?];
        details: {
            errors: Errors;
            page?: Page<SharedPageProps>;
            visitId?: string;
        };
        result: void;
    };
    httpException: {
        parameters: [HttpExceptionResponse];
        details: {
            response: HttpExceptionResponse;
        };
        result: boolean | void;
    };
    networkError: {
        parameters: [Error];
        details: {
            error: Error;
        };
        result: boolean | void;
    };
    prefetched: {
        parameters: [HttpResponse, ActiveVisit<T>];
        details: {
            response: HttpResponse;
            fetchedAt: number;
            visit: ActiveVisit<T>;
        };
        result: void;
    };
    prefetching: {
        parameters: [ActiveVisit<T>];
        details: {
            visit: ActiveVisit<T>;
        };
        result: void;
    };
    flash: {
        parameters: [Page['flash']];
        details: {
            flash: Page['flash'];
        };
        result: void;
    };
    location: {
        parameters: [URL, boolean];
        details: {
            url: URL;
            versionChange: boolean;
        };
        result: boolean | void;
    };
};
export type PageEvent = 'newComponent' | 'firstLoad';
export type GlobalEventNames<T extends RequestPayload = RequestPayload> = keyof GlobalEventsMap<T>;
export type GlobalEvent<TEventName extends GlobalEventNames<T>, T extends RequestPayload = RequestPayload> = CustomEvent<GlobalEventDetails<TEventName, T>>;
export type GlobalEventParameters<TEventName extends GlobalEventNames<T>, T extends RequestPayload = RequestPayload> = GlobalEventsMap<T>[TEventName]['parameters'];
export type GlobalEventResult<TEventName extends GlobalEventNames<T>, T extends RequestPayload = RequestPayload> = GlobalEventsMap<T>[TEventName]['result'];
export type GlobalEventDetails<TEventName extends GlobalEventNames<T>, T extends RequestPayload = RequestPayload> = GlobalEventsMap<T>[TEventName]['details'];
export type GlobalEventTrigger<TEventName extends GlobalEventNames<T>, T extends RequestPayload = RequestPayload> = (...params: GlobalEventParameters<TEventName, T>) => GlobalEventResult<TEventName, T>;
export type GlobalEventCallback<TEventName extends GlobalEventNames<T>, T extends RequestPayload = RequestPayload> = (...params: GlobalEventParameters<TEventName, T>) => GlobalEventResult<TEventName, T>;
export type InternalEvent = 'missingHistoryItem' | 'loadDeferredProps' | 'historyQuotaExceeded';
export type VisitCallbacks<T extends RequestPayload = RequestPayload> = {
    onCancelToken: CancelTokenCallback;
    onBefore: VisitCommandCallback<'before', T>;
    onBeforeUpdate: VisitCommandCallback<'beforeUpdate', T>;
    onStart: VisitCommandCallback<'start', T>;
    onProgress: VisitCommandCallback<'progress', T>;
    onFinish: VisitCommandCallback<'finish', T>;
    onCancel: VisitCommandCallback<'cancel', T>;
    onSuccess: VisitCommandCallback<'success', T>;
    onError: VisitCommandCallback<'error', T>;
    onHttpException: VisitCommandCallback<'httpException', T>;
    onNetworkError: VisitCommandCallback<'networkError', T>;
    onFlash: VisitCommandCallback<'flash', T>;
    onPrefetched: VisitCommandCallback<'prefetched', T>;
    onPrefetching: VisitCommandCallback<'prefetching', T>;
};
/** Command callbacks can suspend; DOM event prevention remains synchronous. */
export type VisitCommandCallback<TEventName extends GlobalEventNames<T>, T extends RequestPayload = RequestPayload> = (...params: GlobalEventParameters<TEventName, T>) => Effectful<GlobalEventResult<TEventName, T> extends void ? unknown : GlobalEventResult<TEventName, T>>;
export type VisitOptions<T extends RequestPayload = RequestPayload> = Partial<Visit<T> & VisitCallbacks<T>>;
export type ReloadOptions<T extends RequestPayload = RequestPayload> = Omit<VisitOptions<T>, 'preserveScroll' | 'preserveState'>;
export type PollOptions = {
    keepAlive?: boolean;
    autoStart?: boolean;
    mode?: 'overlap' | 'cancel' | 'rest';
};
export type VisitHelperOptions<T extends RequestPayload = RequestPayload> = Omit<VisitOptions<T>, 'method' | 'data'>;
export type RouterInitParams<ComponentType = Component> = {
    initialPage: Page;
    resolveComponent: PageResolver;
    swapComponent: PageHandler<ComponentType>;
    onFlash?: (flash: Page['flash']) => void;
};
export type PendingVisitOptions = {
    /** @internal */
    id: string;
    url: URL;
    completed: boolean;
    cancelled: boolean;
    interrupted: boolean;
};
export type PendingVisit<T extends RequestPayload = RequestPayload> = Visit<T> & PendingVisitOptions;
export type ActiveVisit<T extends RequestPayload = RequestPayload> = PendingVisit<T> & Required<Omit<VisitOptions<T>, 'optimistic'>>;
export type InternalActiveVisit = ActiveVisit & {
    onPrefetchResponse?: (response: Response) => void;
    onPrefetchError?: (error: Error) => void;
    deferredProps?: boolean;
    poll?: boolean;
    cached?: boolean;
};
export type VisitId = string;
export type Component = unknown;
type FirstLevelOptional<T> = {
    [K in keyof T]?: T[K] extends object ? {
        [P in keyof T[K]]?: T[K][P];
    } : T[K];
};
type PagesOption = string | {
    path: string;
    extension?: string | string[];
    lazy?: boolean;
    transform?: (name: string, page: Page) => string;
};
export type ProgressOptions = {
    delay?: number;
    color?: string;
    includeCSS?: boolean;
    showSpinner?: boolean;
    popover?: boolean | null;
};
interface BaseCreateInertiaAppOptions<TComponentResolver, TSetupOptions, TSetupReturn, TAdditionalInertiaAppConfig> {
    resolve: TComponentResolver;
    pages?: PagesOption;
    layout?: (name: string, page: Page) => unknown;
    setup: (options: TSetupOptions) => TSetupReturn;
    title?: HeadManagerTitleCallback;
    serverHead?: ServerHeadOption;
    nonce?: string;
    defaults?: FirstLevelOptional<InertiaAppConfig & TAdditionalInertiaAppConfig>;
    /** HTTP client or options to use for requests. Defaults to XhrHttpClient. */
    http?: HttpClient | HttpClientOptions;
    /** Enable development-only integrations. Defaults to `import.meta.env.DEV`. */
    dev?: boolean;
}
export interface CreateInertiaAppOptionsForCSR<SharedProps extends PageProps, TComponentResolver, TSetupOptions, TSetupReturn, TAdditionalInertiaAppConfig> extends BaseCreateInertiaAppOptions<TComponentResolver, TSetupOptions, TSetupReturn, TAdditionalInertiaAppConfig> {
    id?: string;
    page?: Page<SharedProps>;
    progress?: ProgressOptions | false;
    render?: undefined;
}
export interface CreateInertiaAppOptionsForSSR<SharedProps extends PageProps, TComponentResolver, TSetupOptions, TSetupReturn, TAdditionalInertiaAppConfig> extends BaseCreateInertiaAppOptions<TComponentResolver, TSetupOptions, TSetupReturn, TAdditionalInertiaAppConfig> {
    id?: undefined;
    page: Page<SharedProps>;
    progress?: undefined;
    render: unknown;
}
export type InertiaAppSSRResponse = {
    head: string[];
    body: string;
};
export type InertiaAppResponse = Promise<InertiaAppSSRResponse | void>;
export type HeadManagerTitleCallback = (title: string, page: Page) => string;
export type ServerHead = string[];
export type ServerHeadResolver = (page: Page) => ServerHead | null | undefined;
export type ServerHeadOption = boolean | string | ServerHeadResolver;
export interface CreateInertiaAppOptions<TComponentResolver, TSetupOptions, TSetupReturn, TAdditionalInertiaAppConfig> {
    id?: string;
    resolve?: TComponentResolver;
    pages?: PagesOption;
    layout?: (name: string, page: Page) => unknown;
    setup?: (options: TSetupOptions) => TSetupReturn;
    title?: HeadManagerTitleCallback;
    serverHead?: ServerHeadOption;
    progress?: ProgressOptions | false;
    nonce?: string;
    defaults?: FirstLevelOptional<InertiaAppConfig & TAdditionalInertiaAppConfig>;
    /** HTTP client or options to use for requests. Defaults to XhrHttpClient. */
    http?: HttpClient | HttpClientOptions;
    /** Enable development-only integrations. Defaults to `import.meta.env.DEV`. */
    dev?: boolean;
}
export type HeadManagerOnUpdateCallback = (elements: string[]) => void;
export type HeadManager = {
    forceUpdate: () => void;
    updateServerHead: (elements?: string[]) => void;
    createProvider: () => {
        reconnect: () => void;
        update: HeadManagerOnUpdateCallback;
        disconnect: () => void;
    };
};
export type LinkPrefetchOption = 'mount' | 'hover' | 'click';
export type TimeUnit = 'ms' | 's' | 'm' | 'h' | 'd';
export type CacheForOption = number | `${number}${TimeUnit}` | string;
export type PrefetchOptions = {
    cacheFor: CacheForOption | CacheForOption[];
    cacheTags: string | string[];
};
export type InertiaAppConfig = {
    form: {
        recentlySuccessfulDuration: number;
        forceIndicesArrayFormatInFormData: boolean;
        withAllErrors: boolean;
    };
    prefetch: {
        cacheFor: CacheForOption | CacheForOption[];
        hoverDelay: number;
    };
    nonce?: string;
    visitOptions?: (href: string, options: VisitOptions) => VisitOptions;
};
export interface LinkComponentBaseProps extends Partial<Pick<Visit<RequestPayload>, 'component' | 'data' | 'method' | 'replace' | 'preserveScroll' | 'preserveState' | 'preserveUrl' | 'only' | 'except' | 'headers' | 'queryStringArrayFormat' | 'async' | 'viewTransition'> & VisitCallbacks & {
    href: string | UrlMethodPair;
    instant: boolean;
    pageProps: Record<string, unknown> | ((currentProps: PageProps, sharedProps: Partial<PageProps>) => Record<string, unknown>) | null;
    prefetch: boolean | LinkPrefetchOption | LinkPrefetchOption[];
    cacheFor: CacheForOption | CacheForOption[];
    cacheTags: string | string[];
}> {
}
type PrefetchObject = {
    params: ActiveVisit;
    response: Promise<Response>;
};
export type InFlightPrefetch = PrefetchObject & {
    staleTimestamp: null;
    inFlight: true;
};
export type PrefetchCancellationToken = {
    isCancelled: boolean;
    cancel: () => void;
};
export type PrefetchedResponse = PrefetchObject & {
    staleTimestamp: number;
    timestamp: number;
    expiresAt: number;
    singleUse: boolean;
    inFlight: false;
    tags: string[];
};
export type PrefetchRemovalTimer = {
    params: ActiveVisit;
    timer: number;
};
export type ProgressSettings = {
    minimum: number;
    easing: string;
    speed: number;
    trickle: boolean;
    trickleSpeed: number;
    showSpinner: boolean;
    barSelector: string;
    spinnerSelector: string;
    parent: string;
    template: string;
    includeCSS: boolean;
    color: string;
    popover: boolean | null;
};
export type UrlMethodPair = {
    url: string;
    method: Method;
    component?: string | Record<string, string>;
};
export type UseFormTransformCallback<TForm> = (data: TForm) => object;
export type UseFormWithPrecognitionArguments = [Method | (() => Method), string | (() => string)] | [UrlMethodPair | (() => UrlMethodPair)];
type UseFormInertiaArguments<TForm> = [] | [data: TForm | (() => TForm)] | [rememberKey: string, data: TForm | (() => TForm)];
type UseFormPrecognitionArguments<TForm> = [urlMethodPair: UrlMethodPair | (() => UrlMethodPair), data: TForm | (() => TForm)] | [method: Method | (() => Method), url: string | (() => string), data: TForm | (() => TForm)];
export type UseFormArguments<TForm> = UseFormInertiaArguments<TForm> | UseFormPrecognitionArguments<TForm>;
export type UseFormSubmitOptions = Omit<VisitOptions, 'data'>;
export type UseFormSubmitArguments = [Method, string, UseFormSubmitOptions?] | [UrlMethodPair, UseFormSubmitOptions?] | [UseFormSubmitOptions?];
export type UseHttpSubmitArguments<TResponse = unknown, TForm = unknown> = [Method, string, UseHttpSubmitOptions<TResponse, TForm>?] | [UrlMethodPair, UseHttpSubmitOptions<TResponse, TForm>?] | [UseHttpSubmitOptions<TResponse, TForm>?];
export type FormComponentOptions = Pick<VisitOptions, 'preserveScroll' | 'preserveState' | 'preserveUrl' | 'replace' | 'only' | 'except' | 'reset' | 'viewTransition' | 'async'>;
export type FormComponentOptimisticCallback<TProps = Page<SharedPageProps>['props'], TForm = Record<string, FormDataConvertible>> = (props: TProps, formData: TForm) => Partial<TProps> | void;
export type FormComponentProps<TForm = Record<string, FormDataConvertible>> = Partial<Pick<Visit, 'headers' | 'queryStringArrayFormat' | 'errorBag' | 'showProgress' | 'invalidateCacheTags'> & Omit<VisitCallbacks, 'onPrefetched' | 'onPrefetching'>> & {
    method?: Method | Uppercase<Method>;
    action?: string | UrlMethodPair;
    component?: string;
    instant?: boolean;
    transform?: (data: TForm) => Record<string, FormDataConvertible>;
    optimistic?: FormComponentOptimisticCallback<Page<SharedPageProps>['props'], TForm>;
    options?: FormComponentOptions;
    onSubmitComplete?: (props: FormComponentOnSubmitCompleteArguments<TForm & object>) => Effectful<unknown>;
    disableWhileProcessing?: boolean;
    cancelOnUnmount?: boolean;
    resetOnSuccess?: boolean | NoInfer<FormDataKeys<TForm>>[];
    resetOnError?: boolean | NoInfer<FormDataKeys<TForm>>[];
    setDefaultsOnSuccess?: boolean;
    validateFiles?: boolean;
    validationTimeout?: number;
    withAllErrors?: boolean | null;
};
export type FormComponentMethods<TForm extends object = Record<string, any>> = {
    clearErrors: <K extends FormDataKeys<TForm>>(...fields: K[]) => void;
    resetAndClearErrors: <K extends FormDataKeys<TForm>>(...fields: K[]) => void;
    setError: {
        <K extends FormDataKeys<TForm>>(field: K, value: ErrorValue): void;
        (errors: FormDataErrors<TForm>): void;
    };
    reset: <K extends FormDataKeys<TForm>>(...fields: K[]) => void;
    submit: () => void;
    cancel: () => void;
    defaults: () => void;
    getData: () => TForm;
    getFormData: () => FormData;
    valid: <K extends FormDataKeys<TForm>>(field: K) => boolean;
    invalid: <K extends FormDataKeys<TForm>>(field: K) => boolean;
    validate: <K extends FormDataKeys<TForm>>(field?: K | NamedInputEvent | ValidationConfig, config?: ValidationConfig) => void;
    touch: <K extends FormDataKeys<TForm>>(...fields: K[]) => void;
    touched: <K extends FormDataKeys<TForm>>(field?: K) => boolean;
    validator: () => Validator;
};
export type FormComponentOnSubmitCompleteArguments<TForm extends object = Record<string, any>> = Pick<FormComponentMethods<TForm>, 'reset' | 'defaults'>;
export type FormComponentState<TForm extends object = Record<string, any>> = {
    errors: FormDataErrors<TForm>;
    hasErrors: boolean;
    processing: boolean;
    progress: Progress | null;
    wasSuccessful: boolean;
    recentlySuccessful: boolean;
    isDirty: boolean;
    validating: boolean;
};
export type FormComponentSlotProps<TForm extends object = Record<string, any>> = FormComponentMethods<TForm> & FormComponentState<TForm>;
export type FormComponentRef<TForm extends object = Record<string, any>> = FormComponentSlotProps<TForm>;
export interface UseInfiniteScrollOptions {
    getPropName: () => string;
    inReverseMode: () => boolean;
    shouldFetchNext: () => boolean;
    shouldFetchPrevious: () => boolean;
    shouldPreserveUrl: () => boolean;
    getReloadOptions?: () => ReloadOptions;
    getTriggerMargin: () => number;
    getStartElement: () => HTMLElement;
    getEndElement: () => HTMLElement;
    getItemsElement: () => HTMLElement;
    getScrollableParent: () => HTMLElement | null;
    onBeforePreviousRequest: () => void;
    onBeforeNextRequest: () => void;
    onCompletePreviousRequest: (details: InfiniteScrollOnCompleteDetails) => void;
    onCompleteNextRequest: (details: InfiniteScrollOnCompleteDetails) => void;
    onDataReset?: () => void;
}
export interface UseInfiniteScrollDataManager {
    getLastLoadedPage: () => InfiniteScrollPageIdentifier;
    getPageName: () => string;
    getRequestCount: () => number;
    hasPrevious: () => boolean;
    hasNext: () => boolean;
    fetchNext: (reloadOptions?: ReloadOptions) => void;
    fetchPrevious: (reloadOptions?: ReloadOptions) => void;
    removeEventListener: () => void;
}
export interface UseInfiniteScrollElementManager {
    setupObservers: () => void;
    enableTriggers: () => void;
    disableTriggers: () => void;
    refreshTriggers: () => void;
    flushAll: () => void;
    processManuallyAddedElements: () => void;
    processServerLoadedElements: (loadedPage: InfiniteScrollPageIdentifier) => void;
}
export interface UseInfiniteScrollProps {
    dataManager: UseInfiniteScrollDataManager;
    elementManager: UseInfiniteScrollElementManager;
    flush: () => void;
}
export interface InfiniteScrollSlotProps {
    loading: boolean;
    loadingPrevious: boolean;
    loadingNext: boolean;
}
export interface InfiniteScrollActionSlotProps {
    loading: boolean;
    loadingPrevious: boolean;
    loadingNext: boolean;
    fetch: () => void;
    autoMode: boolean;
    manualMode: boolean;
    hasMore: boolean;
    hasPrevious: boolean;
    hasNext: boolean;
}
export interface InfiniteScrollRef {
    fetchNext: (reloadOptions?: ReloadOptions) => void;
    fetchPrevious: (reloadOptions?: ReloadOptions) => void;
    hasPrevious: () => boolean;
    hasNext: () => boolean;
}
export interface InfiniteScrollComponentBaseProps {
    data: string;
    buffer?: number;
    as?: string;
    manual?: boolean;
    manualAfter?: number;
    preserveUrl?: boolean;
    reverse?: boolean;
    autoScroll?: boolean;
    onlyNext?: boolean;
    onlyPrevious?: boolean;
}
export type UseHttpOptions<TResponse = unknown> = {
    onBefore?: () => Effectful<boolean | void>;
    onStart?: () => Effectful<unknown>;
    onProgress?: (progress: HttpProgressEvent) => Effectful<unknown>;
    onSuccess?: (response: TResponse, httpResponse: HttpResponse) => Effectful<unknown>;
    onError?: (errors: Errors) => Effectful<unknown>;
    onHttpException?: (response: HttpResponse) => Effectful<boolean | void>;
    onNetworkError?: (error: Error) => Effectful<boolean | void>;
    onFinish?: () => Effectful<unknown>;
    onCancel?: () => Effectful<unknown>;
    onCancelToken?: (cancelToken: CancelToken) => Effectful<unknown>;
};
export type UseHttpSubmitOptions<TResponse = unknown, TForm = unknown> = UseHttpOptions<TResponse> & {
    headers?: HttpRequestHeaders;
    optimistic?: (currentData: TForm) => Partial<TForm> | void;
};
declare global {
    interface DocumentEventMap {
        'inertia:before': GlobalEvent<'before'>;
        'inertia:start': GlobalEvent<'start'>;
        'inertia:progress': GlobalEvent<'progress'>;
        'inertia:success': GlobalEvent<'success'>;
        'inertia:error': GlobalEvent<'error'>;
        'inertia:httpException': GlobalEvent<'httpException'>;
        'inertia:networkError': GlobalEvent<'networkError'>;
        'inertia:finish': GlobalEvent<'finish'>;
        'inertia:beforeUpdate': GlobalEvent<'beforeUpdate'>;
        'inertia:navigate': GlobalEvent<'navigate'>;
        'inertia:clientVisit': GlobalEvent<'clientVisit'>;
        'inertia:flash': GlobalEvent<'flash'>;
        'inertia:location': GlobalEvent<'location'>;
    }
}
/** Navigation results remain distinct from transport/protocol failures. */
export type VisitOutcome = {
    readonly _tag: 'Success';
    readonly page: Page;
} | {
    readonly _tag: 'Validation';
    readonly page: Page;
    readonly errors: Errors;
} | {
    readonly _tag: 'Cancelled';
} | {
    readonly _tag: 'Interrupted';
} | {
    readonly _tag: 'Prevented';
} | {
    readonly _tag: 'Redirected';
    readonly url: string;
} | {
    readonly _tag: 'Discarded';
    readonly page: Page;
} | {
    readonly _tag: 'HttpException';
    readonly response: HttpResponse;
} | {
    readonly _tag: 'NetworkError';
    readonly error: HttpNetworkError;
};
export {};
