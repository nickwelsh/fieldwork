/** Files are immutable native handles; copying their internals corrupts Node/browser Blob state. */
export declare function cloneFormData<T>(data: T): T;
