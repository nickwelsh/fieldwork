import { Effect } from 'effect';
import { PageCommitOptions } from './page';
import { RequestParams } from './requestParams';
import type { VisitOutcome } from './types';
import { ActiveVisit, ErrorBag, Errors, HttpResponse, Page, PageProps } from './types';
export declare class Response {
    protected requestParams: RequestParams;
    protected response: HttpResponse;
    protected originatingPage: Page;
    protected optimisticId: number | null;
    protected wasPrefetched: boolean;
    protected processed: boolean;
    outcome?: VisitOutcome;
    constructor(requestParams: RequestParams, response: HttpResponse, originatingPage: Page, optimisticId?: number | null);
    static create(params: RequestParams, response: HttpResponse, originatingPage: Page, optimisticId?: number | null): Response;
    isProcessed(): boolean;
    handlePrefetch(): Promise<unknown>;
    handlePrefetchEffect(): Effect.Effect<unknown, unknown>;
    handle(): Promise<unknown>;
    handleEffect(): Effect.Effect<void, unknown>;
    process(): Promise<void>;
    processEffect(): Effect.Effect<void, unknown>;
    mergeParams(params: ActiveVisit): void;
    getPageResponse(): Page;
    protected handleNonInertiaResponseEffect(): Effect.Effect<void, unknown>;
    protected isInertiaResponse(): boolean;
    protected isHttpException(): boolean;
    protected hasStatus(status: number): boolean;
    protected getHeader(header: string): string;
    protected hasHeader(header: string): boolean;
    protected isInertiaRedirect(): boolean;
    protected isLocationVisit(): boolean;
    /**
     * @link https://inertiajs.com/redirects#external-redirects
     */
    protected locationVisit(url: URL): boolean | void;
    protected setPageEffect(): Effect.Effect<void, unknown>;
    protected getDataFromResponse(response: any): any;
    protected shouldSetPage(pageResponse: Page): boolean;
    protected pageUrl(pageResponse: Page): string;
    protected preserveOptimisticProps(pageResponse: Page): PageCommitOptions['optimisticBaseline'];
    protected isStaleOptimisticResponse(): boolean;
    protected preserveEqualProps(pageResponse: Page): void;
    protected mergeProps(pageResponse: Page): void;
    protected mergeRescuedProps(pageResponse: Page): string[];
    /**
     * By default, the Laravel adapter shares validation errors via Inertia::always(),
     * so responses always include errors, even when empty. Components like
     * InfiniteScroll and WhenVisible, as well as loading deferred props,
     * perform async requests that should practically never reset errors.
     */
    protected shouldPreserveErrors(pageResponse: Page): boolean;
    protected isObject(item: any): boolean;
    protected deepMergeObjects(target: PageProps, source: PageProps): PageProps;
    protected mergeOrMatchItems(existingItems: any[], newItems: any[], matchProp: string, matchPropsOn: string[], shouldAppend?: boolean): any[];
    protected appendWithMatching(existingItems: any[], newItems: any[], newItemsMap: Map<any, any>, uniqueProperty: string): any[];
    protected prependWithMatching(existingItems: any[], newItems: any[], newItemsMap: Map<any, any>, uniqueProperty: string): any[];
    protected hasUniqueProperty(item: any, property: string): boolean;
    protected setRememberedStateEffect(pageResponse: Page): Effect.Effect<void, unknown>;
    protected getScopedErrors(errors: Errors & ErrorBag): Errors;
}
