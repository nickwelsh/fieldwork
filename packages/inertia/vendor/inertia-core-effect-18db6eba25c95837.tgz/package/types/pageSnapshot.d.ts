import { Atom, AtomRegistry } from 'effect/reactivity';
import type { Page } from './types';
/** The authoritative browser page. SSR adapters use a request-local snapshot. */
export declare const pageSnapshot: {
    atom: Atom.Writable<Page<import("./types").PageProps> | undefined, Page<import("./types").PageProps> | undefined>;
    registry: AtomRegistry.AtomRegistry;
    getSnapshot: () => Page | undefined;
    subscribe: (callback: () => void) => (() => void);
};
