export type Debounced<F> = F & {
    cancel: () => void;
};
/** Native callbacks enter Effect here; only the latest scheduled invocation survives. */
export default function debounce<F extends (...params: any[]) => ReturnType<F>>(fn: F, delay: number): Debounced<F>;
