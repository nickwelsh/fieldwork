import { HttpResponse } from './types';
export declare class HttpError extends Error {
    readonly _tag: string;
    readonly code: string;
    readonly url?: string;
    constructor(message: string, code: string, url?: string);
}
export declare class HttpResponseError extends HttpError {
    readonly _tag = "HttpResponseError";
    readonly response: HttpResponse;
    constructor(message: string, response: HttpResponse, url?: string);
}
export declare class HttpCancelledError extends HttpError {
    readonly _tag = "HttpCancelledError";
    constructor(message?: string, url?: string);
}
export declare class HttpNetworkError extends HttpError {
    readonly _tag = "HttpNetworkError";
    readonly cause?: Error;
    constructor(message: string, url?: string, cause?: Error);
}
