import { Effect } from 'effect';
import type { EffectFormState } from './formState';
import type { Method, UseHttpSubmitOptions } from './types';
/** One form submission owns its transport, optimistic snapshot, and completion lifecycle. */
export declare function createHttpFormSubmitter<T extends object, TResponse = unknown>(engine: EffectFormState<T>): {
    submitEffect: (method: Method, url: string, options?: UseHttpSubmitOptions<TResponse, T>) => Effect.Effect<TResponse, unknown>;
    submit: (method: Method, url: string, options?: UseHttpSubmitOptions<TResponse, T>) => Promise<TResponse>;
    cancel: () => void | undefined;
    dispose: () => void;
};
