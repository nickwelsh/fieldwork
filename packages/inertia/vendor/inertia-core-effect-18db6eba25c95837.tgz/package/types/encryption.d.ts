import { Effect } from 'effect';
import type { Page } from './types';
export declare const historySessionStorageKeys: {
    key: string;
    iv: string;
};
/** A fresh nonce accompanies every ciphertext; reusing an AES-GCM nonce is unsafe. */
export declare function encryptHistoryEffect(page: Page): Effect.Effect<ArrayBuffer, unknown>;
export declare function decryptHistoryEffect(data: ArrayBuffer): Effect.Effect<any, unknown>;
export declare const encryptHistory: (page: Page) => Promise<ArrayBuffer>;
export declare const decryptHistory: (data: ArrayBuffer) => Promise<any>;
