import { Effect } from 'effect';
import { Request } from './request';
export declare class RequestStream {
    protected requests: Request[];
    private lifetime;
    protected maxConcurrent: number;
    protected interruptible: boolean;
    constructor({ maxConcurrent, interruptible }: {
        maxConcurrent: number;
        interruptible: boolean;
    });
    send(request: Request): import("effect/Fiber").Fiber<import("./types").VisitOutcome, unknown>;
    sendEffect(request: Request): Effect.Effect<import('./types').VisitOutcome, unknown>;
    dispose(): Effect.Effect<void>;
    interruptInFlight(): void;
    cancelInFlight(options?: {
        prefetch?: boolean;
        optimistic?: boolean;
    } | ((request: Request) => boolean)): void;
    protected cancel({ cancelled, interrupted }?: {
        cancelled?: boolean | undefined;
        interrupted?: boolean | undefined;
    }, force?: boolean): void;
    protected shouldCancel(): boolean;
    hasPendingOptimistic(): boolean;
}
