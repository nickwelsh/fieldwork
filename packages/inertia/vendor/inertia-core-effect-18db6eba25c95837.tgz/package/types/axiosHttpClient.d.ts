import { Effect } from 'effect';
import { HttpCancelledError, HttpNetworkError, HttpResponseError } from './httpErrors';
import { HttpClient, HttpRequestConfig, HttpResponse } from './types';
type AxiosProgressEvent = {
    loaded: number;
    total?: number;
    progress?: number;
};
type AxiosInstance = (config: Omit<HttpRequestConfig, 'headers' | 'onUploadProgress'> & {
    headers: Record<string, string>;
    responseType: 'text';
    onUploadProgress?: (event: AxiosProgressEvent) => void;
}) => Promise<Omit<HttpResponse, 'headers'> & {
    headers: unknown;
}>;
export declare class AxiosHttpClient implements HttpClient {
    private readonly instance?;
    constructor(instance?: AxiosInstance | undefined);
    request(config: HttpRequestConfig): Promise<HttpResponse>;
    requestEffect(config: HttpRequestConfig): Effect.Effect<HttpResponse, unknown>;
    protected doRequestEffect(config: HttpRequestConfig): Effect.Effect<HttpResponse, HttpResponseError | HttpNetworkError | HttpCancelledError>;
}
/**
 * Create an Axios HTTP client adapter
 */
export declare function axiosAdapter(instance?: AxiosInstance): HttpClient;
export {};
