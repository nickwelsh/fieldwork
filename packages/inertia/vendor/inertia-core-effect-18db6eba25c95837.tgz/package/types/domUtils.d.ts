import { Effect } from 'effect';
/** Frame acknowledgements release every scheduled frame on completion or interruption. */
export declare function animationFrameEffect(callback: () => void, times?: number): Effect.Effect<void, unknown>;
export declare const getScrollableParent: (element: HTMLElement | null) => HTMLElement | null;
export declare const getElementsInViewportFromCollection: (elements: HTMLElement[], referenceElement?: HTMLElement) => HTMLElement[];
export declare const getInitialPageFromDOM: <T>(id: string) => T | null;
