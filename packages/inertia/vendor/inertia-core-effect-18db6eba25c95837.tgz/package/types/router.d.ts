import { Effect, Fiber } from 'effect';
import { NavigationFailure } from './navigationError';
import Queue from './queue';
import { RequestStream } from './requestStream';
import { ActiveVisit, ClientSideVisitOptions, Component, FlashData, GlobalEvent, GlobalEventNames, GlobalEventResult, InFlightPrefetch, OptimisticCallback, Page, PageFlashData, PageProps, PendingVisit, PollOptions, PrefetchedResponse, PrefetchOptions, ReloadOptions, RequestPayload, RouterInitParams, UrlMethodPair, VisitCallbacks, VisitHelperOptions, VisitOptions } from './types';
export declare class Router {
    private lifetime;
    private initialized;
    private initialReady;
    private cleanup;
    /** Navigation work belongs to the application, even when its initiating view unmounts. */
    forkEffect<A, E>(effect: Effect.Effect<A, E>): Fiber.Fiber<A, E>;
    protected syncRequestStream: RequestStream;
    protected asyncRequestStream: RequestStream;
    protected clientVisitQueue: Queue;
    protected pendingOptimisticCallback: OptimisticCallback | undefined;
    init<ComponentType = Component>({ initialPage, resolveComponent, swapComponent, onFlash, }: RouterInitParams<ComponentType>): void;
    /** Completes after the initial page commit, scroll restoration and navigation event. */
    readyEffect(): Effect.Effect<void, unknown>;
    ready(): Promise<void>;
    optimistic<TProps>(callback: OptimisticCallback<TProps>): this;
    get<T extends RequestPayload = RequestPayload>(url: URL | string | UrlMethodPair, data?: T, options?: VisitHelperOptions<T>): void;
    post<T extends RequestPayload = RequestPayload>(url: URL | string | UrlMethodPair, data?: T, options?: VisitHelperOptions<T>): void;
    put<T extends RequestPayload = RequestPayload>(url: URL | string | UrlMethodPair, data?: T, options?: VisitHelperOptions<T>): void;
    patch<T extends RequestPayload = RequestPayload>(url: URL | string | UrlMethodPair, data?: T, options?: VisitHelperOptions<T>): void;
    delete<T extends RequestPayload = RequestPayload>(url: URL | string | UrlMethodPair, options?: Omit<VisitOptions<T>, 'method'>): void;
    reload<T extends RequestPayload = RequestPayload>(options?: ReloadOptions<T>): void;
    protected doReload<T extends RequestPayload = RequestPayload>(options?: ReloadOptions<T> & {
        deferredProps?: boolean;
        poll?: boolean;
    }): void;
    remember(data: unknown, key?: string): void;
    restore<T = unknown>(key?: string): T | undefined;
    on<TEventName extends GlobalEventNames>(type: TEventName, callback: (event: GlobalEvent<TEventName>) => GlobalEventResult<TEventName>): VoidFunction;
    once<TEventName extends GlobalEventNames>(type: TEventName, callback: (event: GlobalEvent<TEventName>) => GlobalEventResult<TEventName>): VoidFunction;
    hasPendingOptimistic(): boolean;
    get activePolls(): number;
    cancelAll({ async, prefetch, sync }?: {
        async?: boolean | undefined;
        prefetch?: boolean | undefined;
        sync?: boolean | undefined;
    }): void;
    poll(interval: number, requestOptions?: ReloadOptions | (() => ReloadOptions), options?: PollOptions): {
        stop: VoidFunction;
        start: VoidFunction;
        destroy: VoidFunction;
    };
    visit<T extends RequestPayload = RequestPayload>(href: string | URL | UrlMethodPair, options?: VisitOptions<T>): void;
    /** Composes the whole navigation, including cancellation and render acknowledgement. */
    visitEffect<T extends RequestPayload = RequestPayload>(href: string | URL | UrlMethodPair, options?: VisitOptions<T>): Effect.Effect<import('./types').VisitOutcome, NavigationFailure>;
    private performVisitEffect;
    reloadEffect<T extends RequestPayload = RequestPayload>(options?: ReloadOptions<T>): Effect.Effect<import('./types').VisitOutcome, unknown>;
    teardown(): void;
    getCached(href: string | URL | UrlMethodPair, options?: VisitOptions): InFlightPrefetch | PrefetchedResponse | null;
    flush(href: string | URL | UrlMethodPair, options?: VisitOptions): void;
    flushAll(): void;
    flushByCacheTags(tags: string | string[]): void;
    getPrefetching(href: string | URL | UrlMethodPair, options?: VisitOptions): InFlightPrefetch | PrefetchedResponse | null;
    prefetch(href: string | URL | UrlMethodPair, options?: VisitOptions, prefetchOptions?: Partial<PrefetchOptions>): void;
    prefetchEffect(href: string | URL | UrlMethodPair, options?: VisitOptions, prefetchOptions?: Partial<PrefetchOptions>): Effect.Effect<void, unknown>;
    clearHistory(): void;
    decryptHistory(): Promise<Page>;
    decryptHistoryEffect(): Effect.Effect<Page, unknown>;
    resolveComponent(component: string, page?: Page): Promise<Component>;
    resolveComponentEffect(component: string, page?: Page): Effect.Effect<Component, unknown>;
    replace<TProps = Page['props']>(params: ClientSideVisitOptions<TProps>): void;
    replaceProp<TProps = Page['props']>(name: string, value: unknown | ((oldValue: unknown, props: TProps) => unknown), options?: Pick<ClientSideVisitOptions, 'onError' | 'onFinish' | 'onSuccess'>): void;
    appendToProp<TProps = Page['props']>(name: string, value: unknown | unknown[] | ((oldValue: unknown, props: TProps) => unknown | unknown[]), options?: Pick<ClientSideVisitOptions, 'onError' | 'onFinish' | 'onSuccess'>): void;
    prependToProp<TProps = Page['props']>(name: string, value: unknown | unknown[] | ((oldValue: unknown, props: TProps) => unknown | unknown[]), options?: Pick<ClientSideVisitOptions, 'onError' | 'onFinish' | 'onSuccess'>): void;
    push<TProps = Page['props']>(params: ClientSideVisitOptions<TProps>): void;
    flash<TFlash extends PageFlashData = PageFlashData>(keyOrData: string | ((flash: FlashData) => TFlash) | TFlash, value?: unknown): void;
    protected clientVisit<TProps = Page['props']>(params: ClientSideVisitOptions<TProps>, { replace }?: {
        replace?: boolean;
    }): void;
    clientVisitEffect<TProps = Page['props']>(params: ClientSideVisitOptions<TProps>, options?: {
        replace?: boolean;
    }): Effect.Effect<void, unknown>;
    protected performClientVisitEffect<TProps = Page['props']>(params: ClientSideVisitOptions<TProps>, { replace }?: {
        replace?: boolean;
    }): Effect.Effect<void, unknown>;
    protected performInstantSwapEffect(visit: PendingVisit): Effect.Effect<void, unknown>;
    /**
     * Once props are remembered client-side, so the placeholder page must preserve their values
     * and registry. Otherwise the swap discards the value, and an in-flight prefetch that already
     * claimed the prop resolves with nothing to restore it from.
     */
    protected preserveOncePropsOnInstantVisit(current: Page, props: PageProps): Page['onceProps'];
    protected getPrefetchParams(href: string | URL | UrlMethodPair, options: VisitOptions): ActiveVisit;
    protected createVisitId(): string;
    protected getPendingVisit(href: string | URL | UrlMethodPair, options: VisitOptions): PendingVisit;
    protected getVisitEvents(options: VisitOptions): VisitCallbacks;
    protected applyOptimisticUpdateEffect(optimistic: OptimisticCallback, events: VisitCallbacks, id: number): Effect.Effect<unknown, unknown>;
    protected loadDeferredProps(deferred: Page['deferredProps']): void;
}
export declare const router: Router;
