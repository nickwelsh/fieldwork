import { Effect } from 'effect';
import { EffectFormState } from './formState';
import type { OptimisticCallback, UseFormSubmitArguments, VisitOutcome } from './types';
/** Submission workflow shared by every renderer. Effects complete after the page commit acknowledgement. */
export declare function createFormSubmitter<T extends object>(engine: EffectFormState<T>): {
    submitEffect: (...args: UseFormSubmitArguments) => Effect.Effect<VisitOutcome, unknown>;
    submit: (...args: UseFormSubmitArguments) => void;
    optimistic: (callback: OptimisticCallback) => void;
    cancel: () => void;
};
