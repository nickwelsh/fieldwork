import { Effect, Scope } from 'effect';
import { Atom, AtomRegistry } from 'effect/reactivity';
import { type Effectful } from './effectInterop';
import type { FormDataConvertibleValue, HttpResponse, UrlMethodPair } from './types';
export interface NamedInputEvent extends InputEvent {
    readonly target: EventTarget & {
        name: string;
    };
}
/** Wildcards select actual object keys or array indexes, never arbitrary descendants. */
export type PrecognitionPath<T, Depth extends unknown[] = []> = Depth['length'] extends 8 ? never : 0 extends 1 & T ? string : T extends Function | FormDataConvertibleValue ? never : T extends readonly (infer Item)[] ? '*' | `${number}` | `${'*' | number}.${PrecognitionPath<Item, [...Depth, unknown]>}` : T extends object ? string extends keyof T ? string : '*' | {
    [Key in Extract<keyof T, string>]: Key | `${Key}.${PrecognitionPath<T[Key], [...Depth, unknown]>}`;
}[Extract<keyof T, string>] : never;
export type ValidationErrors = Record<string, string[]>;
export type SimpleValidationErrors = Record<string, string>;
export type ValidationResponse = Omit<HttpResponse, 'data'> & {
    data: unknown;
};
export type ValidationConfig = {
    only?: Iterable<string> | ArrayLike<string>;
    validate?: Iterable<string> | ArrayLike<string>;
    headers?: Record<string, string | number | boolean | undefined>;
    timeout?: number;
    signal?: AbortSignal;
    onBefore?: () => Effectful<boolean | void>;
    onBeforeValidation?: (next: {
        data: Record<string, unknown>;
        touched: string[];
    }, previous: {
        data: Record<string, unknown> | null;
        touched: string[];
    }) => Effectful<boolean | void>;
    onStart?: () => void;
    onSuccess?: (response: ValidationResponse) => unknown;
    onPrecognitionSuccess?: (response: ValidationResponse) => unknown;
    onValidationError?: (response: ValidationResponse, error?: unknown) => unknown;
    onUnauthorized?: (response: ValidationResponse, error?: unknown) => unknown;
    onForbidden?: (response: ValidationResponse, error?: unknown) => unknown;
    onNotFound?: (response: ValidationResponse, error?: unknown) => unknown;
    onConflict?: (response: ValidationResponse, error?: unknown) => unknown;
    onLocked?: (response: ValidationResponse, error?: unknown) => unknown;
    onFinish?: () => void;
};
declare const PrecognitionResponseError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "PrecognitionResponseError";
} & Readonly<A>;
export declare class PrecognitionResponseError extends PrecognitionResponseError_base<{
    readonly message: string;
    readonly response: HttpResponse;
}> {
}
export type ValidatorEvent = 'errorsChanged' | 'validatingChanged' | 'touchedChanged' | 'validatedChanged';
export type Validator = EffectValidator;
export declare const resolveName: (input: string | NamedInputEvent) => string;
export declare const toSimpleValidationErrors: (errors: Record<string, string | string[]>) => SimpleValidationErrors;
export declare const toValidationErrors: (errors: Record<string, string | string[]>) => ValidationErrors;
export declare function expandWildcardPaths(pattern: string, data: Record<string, unknown>): string[];
export type ValidationState = {
    readonly errors: ValidationErrors;
    readonly touched: string[];
    readonly validated: string[];
    readonly validating: boolean;
};
/** Framework-independent Precognition workflow. Interrupting its scope aborts transport and debounce. */
export declare class EffectValidator {
    private readonly endpoint;
    private readonly data;
    readonly atom: Atom.Writable<ValidationState, ValidationState>;
    readonly registry: AtomRegistry.AtomRegistry;
    readonly scope: Scope.Closeable;
    private listeners;
    private delay;
    private files;
    private fiber;
    private generation;
    private lastRequestedAt;
    private previousData;
    private previousTouched;
    private closed;
    constructor(endpoint: () => UrlMethodPair, data: () => Record<string, unknown>, initial?: Record<string, unknown>);
    getSnapshot: () => ValidationState;
    subscribe: (listener: () => void) => (() => void);
    private update;
    touched: () => string[];
    validating: () => boolean;
    valid: () => string[];
    errors: () => ValidationErrors;
    hasErrors: () => boolean;
    on(event: ValidatorEvent, callback: () => void): this;
    touch(input: string | NamedInputEvent | string[]): this;
    setErrors(errors: Record<string, string | string[]>): this;
    forgetError(input: string | NamedInputEvent): this;
    reset(...names: string[]): this;
    setTimeout(duration: number): this;
    validateFiles(): this;
    withoutFileValidation(): this;
    defaults(data: Record<string, unknown>): this;
    cancel(): void;
    dispose(): void;
    validate(input?: string | NamedInputEvent | ValidationConfig, value?: unknown, config?: ValidationConfig): this;
    validateEffect(input?: string | NamedInputEvent | ValidationConfig, value?: unknown, configuration?: ValidationConfig): Effect.Effect<ValidationResponse | undefined, unknown>;
    private executeValidationEffect;
}
export {};
