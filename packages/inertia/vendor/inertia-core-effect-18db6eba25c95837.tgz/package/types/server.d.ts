import { Server } from 'http';
import { Effect } from 'effect';
import { Effectful } from './effectInterop';
import { InertiaAppSSRResponse, Page } from './types';
export type AppCallback = (page: Page, signal?: AbortSignal) => Effectful<InertiaAppSSRResponse | void>;
export type ServerOptions = {
    port?: number;
    host?: string;
    cluster?: boolean;
    formatErrors?: boolean;
};
export type SSRServer = ((page: Page, signal?: AbortSignal) => Promise<InertiaAppSSRResponse | void>) & {
    renderEffect: (page: Page, signal?: AbortSignal) => Effect.Effect<InertiaAppSSRResponse | void, unknown>;
    closeEffect: () => Effect.Effect<void>;
    close: () => Promise<void>;
    readonly server: Server | undefined;
};
export default function createSSRServer(render: AppCallback, options?: number | ServerOptions): SSRServer;
