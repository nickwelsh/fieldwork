import { Effect } from 'effect';
import { HttpClient, HttpClientOptions, HttpRequestConfig, HttpResponse } from './types';
/** Effect's Fetch transport. Upload requests use XHR to retain progress reporting. */
export declare class FetchHttpClientAdapter implements HttpClient {
    private readonly options;
    private readonly uploadClient;
    constructor(options?: HttpClientOptions);
    request(config: HttpRequestConfig): Promise<HttpResponse>;
    requestEffect(config: HttpRequestConfig): Effect.Effect<HttpResponse, unknown>;
    private doRequestEffect;
}
export declare const fetchHttpClient: FetchHttpClientAdapter;
