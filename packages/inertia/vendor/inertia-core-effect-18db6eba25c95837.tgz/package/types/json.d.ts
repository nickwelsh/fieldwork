import type { Page } from './types';
/**
 * Markers are only revived on pages that opted in, so an application sending
 * its own `$bigint` objects receives them untouched.
 */
export declare function parsePage(text: string): any;
/**
 * A page holding BigInt values is flagged as it is serialized, so a page built
 * on the client (or with remembered state) parses back the way it went in.
 */
export declare function stringifyPage(page: Page): string;
/**
 * Request bodies send a BigInt as its digits, the same way form data and query
 * strings do, so the server receives it like any other numeric input.
 */
export declare function stringifyJson(value: any): string;
export declare function containsBigInt(value: any, seen?: WeakSet<object>): boolean;
