import { Effect } from 'effect';
import { Component, FlashData, Page, PageEvent, PageHandler, PageResolver, RouterInitParams, Visit } from './types';
declare class CurrentPage {
    protected get page(): Page;
    protected set page(value: Page);
    protected swapComponent: PageHandler<any>;
    protected resolveComponent: PageResolver;
    protected onFlashCallback?: (flash: Page['flash']) => void;
    protected componentId: {};
    protected listeners: {
        event: PageEvent;
        callback: VoidFunction;
    }[];
    protected isFirstPageLoad: boolean;
    protected cleared: boolean;
    protected historyQuotaExceeded: boolean;
    protected optimisticBaseline: Partial<Page['props']>;
    protected pendingOptimistics: {
        id: number;
        callback: (props: Page['props']) => Partial<Page['props']> | void;
    }[];
    protected optimisticCounter: number;
    protected confirmedOptimisticId: number;
    private pendingInitialDeferredProps?;
    private removeQuotaListener?;
    init<ComponentType = Component>({ initialPage, swapComponent, resolveComponent, onFlash, }: RouterInitParams<ComponentType>): this;
    dispose(): void;
    set(page: Page, options?: PageCommitOptions): Promise<void>;
    setEffect(page: Page, options?: PageCommitOptions): Effect.Effect<void, unknown>;
    setQuietly(page: Page, options?: {
        preserveState?: boolean;
    }): Promise<unknown>;
    setQuietlyEffect(page: Page, { preserveState }?: {
        preserveState?: boolean;
    }): Effect.Effect<unknown, unknown>;
    clear(): void;
    isCleared(): boolean;
    get(): Page;
    getWithoutFlashData(): Page;
    hasOnceProps(): boolean;
    merge(data: Partial<Page>): void;
    setPropsQuietly(props: Page['props']): Promise<unknown>;
    setPropsQuietlyEffect(props: Page['props']): Effect.Effect<unknown, unknown>;
    setFlash(flash: FlashData): void;
    setUrlHash(hash: string): void;
    remember(data: Page['rememberedState']): void;
    swap(args: PageSwap): Promise<unknown>;
    swapEffect({ component, page, preserveState, viewTransition, initialRender, }: PageSwap): Effect.Effect<unknown, unknown>;
    resolve(component: string, page?: Page): Promise<Component>;
    resolveEffect(component: string, page?: Page): Effect.Effect<Component, unknown>;
    nextOptimisticId(): number;
    markOptimisticConfirmed(id: number): void;
    hasConfirmedOptimisticAfter(id: number): boolean;
    setBaseline(key: string, value: unknown): void;
    updateBaseline(key: string, value: unknown): void;
    hasBaseline(key: string): boolean;
    registerOptimistic(id: number, callback: (props: Page['props']) => Partial<Page['props']> | void): void;
    unregisterOptimistic(id: number): void;
    replayOptimistics(): Partial<Page['props']>;
    pendingOptimisticCount(): number;
    hasPendingOptimisticExcept(id: number | null): boolean;
    clearOptimisticState(): void;
    isTheSame(page: Page): boolean;
    on(event: PageEvent, callback: VoidFunction): VoidFunction;
    fireEventsFor(event: PageEvent): void;
    mergeOncePropsIntoResponse(response: Page, { force }?: {
        force?: boolean;
    }): void;
}
export declare const page: CurrentPage;
export type PageCommitOptions = {
    replace?: boolean;
    preserveScroll?: boolean;
    preserveState?: boolean;
    viewTransition?: Visit['viewTransition'];
    cached?: boolean;
    initialRender?: boolean;
    visitId?: string;
    /** Staged server baselines are published only once the page reaches its atomic commit. */
    optimisticBaseline?: {
        updates: ReadonlyMap<string, unknown>;
        optimisticId: number | null;
    };
};
type PageSwap = {
    component: Component;
    page: Page;
    preserveState: boolean;
    viewTransition: Visit['viewTransition'];
    initialRender?: boolean;
};
export {};
