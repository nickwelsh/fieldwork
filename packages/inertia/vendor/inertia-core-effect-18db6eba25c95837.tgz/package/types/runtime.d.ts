import { Context, Effect, Fiber, Layer, Scope } from 'effect';
/** Owns fibers and native resources at the application or component boundary. */
export declare class EffectLifetime {
    readonly scope: Scope.Closeable;
    private closed;
    fork<A, E>(effect: Effect.Effect<A, E>): Fiber.Fiber<A, E>;
    add(cleanup: () => void): void;
    close(): Effect.Effect<void>;
    dispose(): void;
}
declare const InertiaLifetime_base: Context.ServiceClass<InertiaLifetime, "inertia/Lifetime", EffectLifetime>;
export declare class InertiaLifetime extends InertiaLifetime_base {
    static readonly layer: Layer.Layer<InertiaLifetime, never, never>;
}
export {};
