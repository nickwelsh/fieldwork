import { ProgressSettings } from './types';
declare const _default: {
    configure: (options: Partial<ProgressSettings>) => void;
    isStarted: () => boolean;
    done: (force?: boolean) => void;
    set: (n: number) => void;
    remove: () => void;
    start: () => void;
    readonly status: number | null;
    show: () => void;
    hide: () => void;
};
export default _default;
