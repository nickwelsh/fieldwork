import { Effect } from 'effect';
import { HttpCancelledError, HttpNetworkError, HttpResponseError } from './httpErrors';
import { HttpClient, HttpClientOptions, HttpRequestConfig, HttpResponse } from './types';
export declare function getCookie(name: string): string | null;
export declare function isSameOrigin(url: string): boolean;
export declare function isFormDataRequestBody(value: unknown): value is FormData;
export declare function isRawRequestBody(value: unknown): value is XMLHttpRequestBodyInit;
export declare function buildUrlWithParams(url: string, params?: Record<string, unknown>): string;
/**
 * Inertia's built-in HTTP client using XMLHttpRequest
 */
export declare class XhrHttpClient implements HttpClient {
    protected xsrfCookieName: string;
    protected xsrfHeaderName: string;
    constructor(options?: HttpClientOptions);
    request(config: HttpRequestConfig): Promise<HttpResponse>;
    requestEffect(config: HttpRequestConfig): Effect.Effect<HttpResponse, unknown>;
    protected doRequestEffect(config: HttpRequestConfig): Effect.Effect<HttpResponse, HttpResponseError | HttpNetworkError | HttpCancelledError>;
}
export declare const xhrHttpClient: XhrHttpClient;
