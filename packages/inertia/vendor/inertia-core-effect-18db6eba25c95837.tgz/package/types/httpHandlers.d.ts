import { HttpCancelledError, HttpNetworkError, HttpResponseError } from './httpErrors';
import { HttpErrorHandler, HttpRequestConfig, HttpRequestHandler, HttpResponse, HttpResponseHandler } from './types';
declare class HttpHandlers {
    protected requestHandlers: HttpRequestHandler[];
    protected responseHandlers: HttpResponseHandler[];
    protected errorHandlers: HttpErrorHandler[];
    executeEffect(config: HttpRequestConfig, send: (config: HttpRequestConfig) => Effect.Effect<HttpResponse, unknown>): Effect.Effect<HttpResponse, unknown>;
    onRequest(handler: HttpRequestHandler): () => void;
    onResponse(handler: HttpResponseHandler): () => void;
    onError(handler: HttpErrorHandler): () => void;
    processRequestEffect(config: HttpRequestConfig): Effect.Effect<HttpRequestConfig, unknown>;
    processResponseEffect(response: HttpResponse): Effect.Effect<HttpResponse, unknown>;
    processErrorEffect(error: HttpResponseError | HttpNetworkError | HttpCancelledError): Effect.Effect<void, unknown>;
    processRequest(config: HttpRequestConfig): Promise<HttpRequestConfig>;
    processResponse(response: HttpResponse): Promise<HttpResponse>;
    processError(error: HttpResponseError | HttpNetworkError | HttpCancelledError): Promise<void>;
}
export declare const httpHandlers: HttpHandlers;
import { Effect } from 'effect';
export {};
