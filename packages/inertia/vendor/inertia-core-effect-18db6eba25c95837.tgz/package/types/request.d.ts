import { Effect } from 'effect';
import { RequestParams } from './requestParams';
import { Response } from './response';
import type { ActiveVisit, Page } from './types';
import { HttpProgressEvent, HttpRequestHeaders } from './types';
export declare class Request {
    protected page: Page;
    protected response: Response;
    protected cancelToken: AbortController;
    protected requestParams: RequestParams;
    protected requestHasFinished: boolean;
    protected optimisticId: number | null;
    private readonly callbackLifetime;
    private readonly callbackLock;
    private callbackFibers;
    private finalPage?;
    private handledOutcome?;
    private readonly cancellation;
    private callbackContext;
    constructor(params: ActiveVisit, page: Page, { optimisticId }?: {
        optimisticId?: number | null;
    });
    static create(params: ActiveVisit, page: Page, options?: {
        optimisticId?: number | null;
    }): Request;
    isPrefetch(): boolean;
    getUrl(): URL;
    isOptimistic(): boolean;
    isPendingOptimistic(): boolean;
    send(): Promise<void>;
    sendEffect(): Effect.Effect<void, unknown>;
    getOutcome(): import('./types').VisitOutcome;
    protected finishEffect(): Effect.Effect<void, unknown>;
    private drainCallbacksEffect;
    private scheduleCallback;
    cancel({ cancelled, interrupted }: {
        cancelled?: boolean;
        interrupted?: boolean;
    }): void;
    protected onProgress(progress: HttpProgressEvent): void;
    protected getHeaders(): HttpRequestHeaders;
}
