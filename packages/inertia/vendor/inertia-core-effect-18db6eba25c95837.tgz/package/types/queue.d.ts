import { Effect } from 'effect';
export default class Queue {
    private readonly semaphore;
    /** Serializes native operations without crossing a Promise execution boundary. */
    runEffect<A, E>(effect: Effect.Effect<A, E>): Effect.Effect<A, E>;
}
