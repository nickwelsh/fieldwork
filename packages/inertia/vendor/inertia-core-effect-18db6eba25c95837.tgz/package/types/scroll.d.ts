import { Effect } from 'effect';
import { ScrollRegion } from './types';
export declare class Scroll {
    static save(): void;
    static getScrollRegions(): ScrollRegion[];
    protected static regions(): NodeListOf<Element>;
    static scrollToTopEffect(): Effect.Effect<void, unknown>;
    static resetEffect(): Effect.Effect<void, unknown>;
    static scrollToAnchorEffect(): Effect.Effect<void, unknown>;
    static restore(scrollRegions: ScrollRegion[], documentScrollPosition?: ScrollRegion): void;
    static restoreEffect(scrollRegions: ScrollRegion[], documentScrollPosition?: ScrollRegion): Effect.Effect<void, unknown>;
    static restoreScrollRegions(scrollRegions: ScrollRegion[]): void;
    static restoreDocument(scrollPosition?: ScrollRegion): void;
    static onScroll(event: Event): void;
    static onWindowScroll(): void;
}
