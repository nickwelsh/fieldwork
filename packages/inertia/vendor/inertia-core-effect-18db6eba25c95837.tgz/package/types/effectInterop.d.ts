import { Effect } from 'effect';
export type Effectful<A> = A | PromiseLike<A> | Effect.Effect<A, unknown>;
/** Effect.callback's returned cleanup only runs on interruption. This lease
 * releases event listeners and browser resources on every completion path. */
export declare function callbackWithCleanup<A, E = never>(register: (resume: (effect: Effect.Effect<A, E>) => void, signal: AbortSignal) => void | Effect.Effect<void>): Effect.Effect<A, E>;
/** Execute user callbacks lazily, preserving their typed failures. */
export declare function fromEffectful<A>(evaluate: () => Effectful<A>): Effect.Effect<A, unknown>;
/** The Promise API rejects with the original failure, including HttpError instances. */
export declare function runEffectPromise<A, E>(effect: Effect.Effect<A, E>, signal?: AbortSignal): Promise<A>;
