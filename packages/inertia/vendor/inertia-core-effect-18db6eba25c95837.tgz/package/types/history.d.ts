import { Effect } from 'effect';
import { Page, ScrollRegion } from './types';
declare class History {
    rememberedState: "rememberedState";
    scrollRegions: "scrollRegions";
    preserveUrl: boolean;
    protected current: Partial<Page>;
    protected initialState: Partial<Page> | null;
    remember(data: unknown, key: string): void;
    restore(key: string): unknown;
    pushState(page: Page, cb?: (() => void) | null): void;
    /** History writes are serialized, including encryption and native throttling protection. */
    writeEffect(page: Page, replace: boolean): Effect.Effect<void, unknown>;
    protected clonePageProps(page: Page): Page;
    protected getPageDataEffect(page: Page): Effect.Effect<Page | ArrayBuffer, unknown>;
    processQueue(): Promise<void>;
    processQueueEffect(): Effect.Effect<void>;
    decrypt(page?: Page | null): Promise<Page>;
    decryptEffect(page?: Page | null): Effect.Effect<Page, unknown>;
    saveScrollPositions(scrollRegions: ScrollRegion[]): void;
    saveDocumentScrollPosition(scrollRegion: ScrollRegion): void;
    getScrollRegions(): ScrollRegion[];
    getDocumentScrollPosition(): ScrollRegion;
    replaceState(page: Page, cb?: (() => void) | null): void;
    protected isHistoryThrottleError(error: unknown): error is Error & {
        name: 'SecurityError';
    };
    protected isQuotaExceededError(error: unknown): error is Error & {
        name: 'QuotaExceededError';
    };
    protected withThrottleProtection<T = void>(cb: () => T): Effect.Effect<T | undefined, unknown>;
    protected doReplaceState(data: {
        page: Page | ArrayBuffer;
        scrollRegions?: ScrollRegion[];
        documentScrollPosition?: ScrollRegion;
    }, url?: string): Effect.Effect<void, unknown>;
    protected doPushState(data: {
        page: Page | ArrayBuffer;
        scrollRegions?: ScrollRegion[];
        documentScrollPosition?: ScrollRegion;
    }, url: string): Effect.Effect<void, unknown>;
    getState<T>(key: keyof Page, defaultValue?: T): any;
    deleteState(key: keyof Page): void;
    clearInitialState(key: keyof Page): void;
    browserHasHistoryEntry(): boolean;
    clear(): void;
    setCurrent(page: Page): void;
    isValidState(state: any): boolean;
    getAllState(): Page;
}
export declare const history: History;
export {};
